<?php
// Contact form processing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"] ?? '';
    $email = $_POST["email"] ?? '';
    $message = $_POST["message"] ?? '';

    // MySQL connection (change DB name if needed)
    $conn = new mysqli("localhost", "u970167584_principal", "Sd11kk@09", "u970167584_college_db");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert into contact_messages table
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    if ($stmt->execute()) {
        $success = "✅ Your message has been sent successfully.";
    } else {
        $error = "❌ Failed to send message. Please try again.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - Dr. P. N. Singh Degree College</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing: border-box; }

    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f4f4f4;
    }

    header {
      background-color: #002147;
      color: white;
      padding: 20px;
      text-align: center;
    }

    nav {
      background-color: #003366;
      padding: 10px 0;
      text-align: center;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      font-weight: bold;
      font-size: 16px;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .contact-box {
      max-width: 600px;
      margin: 40px auto;
      padding: 30px;
      background-color: #fff;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      border-radius: 10px;
    }

    .contact-info {
      background-color: #e9f5ff;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 6px;
    }

    .form-control {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button {
      width: 100%;
      background-color: #002147;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #004080;
    }

    .success { color: green; margin-bottom: 15px; }
    .error { color: red; margin-bottom: 15px; }

    footer {
      background-color: #002147;
      color: white;
      padding: 20px;
      text-align: center;
      margin-top: 40px;
    }

    @media (max-width: 768px) {
      nav a {
        display: block;
        margin: 10px 0;
      }

      .contact-box {
        margin: 20px;
        padding: 20px;
      }
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header>
    <h1>Dr. P. N. Singh Degree College, Chapra</h1>
    <p>Affiliated to Jai Prakash University</p>
  </header>

  <!-- Navbar -->
  <nav>
    <a href="home.html">Home</a>
    
  </nav>

  <!-- Contact Form -->
  <section class="contact-box">
    <h2 style="text-align: center;">📞 Contact Us Regarding Admission</h2>

    <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

    <div class="contact-info">
      <h3>👨‍🏫 Principal</h3>
      <p><strong>Name:</strong> Dr. Vivekanand Tiwari</p>
      <p><strong>Mobile:</strong> +91-7633035882</p>
    </div>

    <div class="contact-info">
      <h3>🎓 Admission Incharge</h3>
      <p><strong>Name:</strong> Prof. Triloki nath upadhyay</p>
      <p><strong>Email:</strong> NA</p>
      <p><strong>Mobile:</strong> +91-8229033094</p>
    </div>

    <form action="contact.php" method="POST">
      <label><strong>Your Name:</strong></label>
      <input type="text" name="name" required class="form-control">

      <label><strong>Your Email:</strong></label>
      <input type="email" name="email" required class="form-control">

      <label><strong>Your Message:</strong></label>
      <textarea name="message" rows="5" required class="form-control"></textarea>

      <button type="submit">Send Message</button>
    </form>
  </section>

  <!-- Footer -->
  <footer>
    <p>© 2025 Dr. P. N. Singh Degree College, Chapra | Designed by Kishan</p>
  </footer>

</body>
</html>

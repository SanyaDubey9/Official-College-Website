<?php
$success = "";
$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"] ?? '';
    $mobile = $_POST["mobile"] ?? '';
    $email = $_POST["email"] ?? '';
    $roll_no = $_POST["roll_no"] ?? '';
    $description = $_POST["description"] ?? '';

    // Connect to DB
    $conn = new mysqli("localhost", "u970167584_principal", "Sd11kk@09", "u970167584_college_db");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare insert query
    $stmt = $conn->prepare("INSERT INTO grievance (name, mobile, email, roll_no, description, submitted_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssss", $name, $mobile, $email, $roll_no, $description);

    if ($stmt->execute()) {
        $success = "Your grievance has been submitted successfully.";
    } else {
        $error = "Error submitting grievance. Please try again.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Submit Your Grievance</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #eef6ff;
    }

    header {
      background-color: #0055aa;
      color: white;
      padding: 25px;
      text-align: center;
      font-size: 24px;
    }

    .form-box {
      max-width: 600px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    label {
      font-weight: bold;
    }

    .form-control {
      width: 100%;
      padding: 12px;
      margin: 10px 0 20px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #0055aa;
      color: white;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button:hover {
      background-color: #003f80;
    }

    .success { color: green; margin-bottom: 15px; }
    .error { color: red; margin-bottom: 15px; }

    footer {
      background-color: #0055aa;
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }

    @media (max-width: 768px) {
      .form-box {
        margin: 20px;
        padding: 20px;
      }

      header {
        font-size: 20px;
      }
    }
  </style>
</head>
<body>

  <header>
    Submit Your Grievance - Dr. P. N. Singh Degree College
  </header>

  <div class="form-box">
    <h2 style="text-align:center;">Grievance Submission Form</h2>

    <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST" action="grievance.php">
      <label for="name">Full Name:</label>
      <input type="text" name="name" required class="form-control">

      <label for="mobile">Mobile Number:</label>
      <input type="text" name="mobile" required class="form-control">

      <label for="email">Email Address:</label>
      <input type="email" name="email" required class="form-control">

      <label for="roll_no">Roll Number:</label>
      <input type="text" name="roll_no" required class="form-control">

      <label for="description">Grievance Description:</label>
      <textarea name="description" rows="5" required class="form-control"></textarea>

      <button type="submit">Submit Grievance</button>
    </form>
  </div>

  <footer>
    © 2025 Dr. P. N. Singh Degree College | Grievance Cell
  </footer>

</body>
</html>

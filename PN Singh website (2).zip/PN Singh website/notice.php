<?php
$conn = new mysqli("localhost", "u970167584_principal", "Sd11kk@09", "u970167584_college_db"); // update DB name if needed
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM notices ORDER BY uploaded_on DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>📢 College Notices - Dr. P. N. Singh Degree College</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing: border-box; }

    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f5f5f5;
    }

    header {
      background-color: #002147;
      color: white;
      padding: 25px 20px;
      text-align: center;
    }

    nav {
      background-color: #004080;
      padding: 10px;
      text-align: center;
    }

    nav a {
      color: #fff;
      text-decoration: none;
      margin: 0 15px;
      font-weight: bold;
      font-size: 16px;
    }

    nav a:hover { text-decoration: underline; }

    h2 {
      text-align: center;
      margin-top: 30px;
      color: #002147;
    }

    .notice-board {
      background-color: #fff0f0;
      margin: 20px auto;
      padding: 20px;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
      border-radius: 10px;
    }

    marquee {
      height: 300px;
      overflow: hidden;
      display: block;
    }

    .notice-link {
      display: block;
      padding: 12px;
      background-color: #fff;
      margin: 8px 0;
      border-left: 5px solid #004080;
      text-decoration: none;
      color: #333;
      font-weight: bold;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .notice-link:hover {
      background-color: #e0f0ff;
      color: #002147;
    }

    footer {
      background-color: #002147;
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }

    @media (max-width: 768px) {
      nav a {
        display: block;
        margin: 10px 0;
      }
      .notice-board {
        width: 95%;
        padding: 15px;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>Dr. P. N. Singh Degree College, Chapra</h1>
  <p>Affiliated to Jai Prakash University</p>
</header>

<nav>
  <a href="index.html">Home</a>
  <a href="about.html">About</a>
  <a href="departments.html">Departments</a>
  <a href="contact.php">Contact</a>
</nav>

<h2>📢 Latest Notices / Downloads</h2>

<div class="notice-board">
  <marquee direction="up" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
    <?php if ($result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <a class="notice-link" href="notice_files/<?php echo htmlspecialchars($row['file']); ?>" download>
          📄 <?php echo htmlspecialchars($row['title']); ?>
        </a>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No notices found.</p>
    <?php endif; ?>
  </marquee>
</div>

<footer>
  <p>© 2025 Dr. P. N. Singh Degree College, Chapra | Designed by Kishan</p>
</footer>

</body>
</html>

<?php $conn->close(); ?>

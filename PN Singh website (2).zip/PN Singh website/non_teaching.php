<?php
$conn = new mysqli("localhost", "u970167584_principal", "Sd11kk@09", "u970167584_college_db");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }
$result = $conn->query("SELECT * FROM non_teaching_staff");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Our Non-Teaching Staff</title>
    <style>
        body { font-family: Arial; margin: 0; background: #f1f1f1; }
        header { background: #0077b6; color: white; padding: 15px; text-align: center; }
        footer { background: #0077b6; color: white; padding: 10px; text-align: center; margin-top: 20px; }
        .staff-container { display: flex; flex-wrap: wrap; justify-content: center; padding: 20px; }
        .staff-card { background: white; margin: 15px; padding: 15px; border-radius: 8px; width: 250px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); text-align: center; }
        img { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; }
        h3 { margin: 10px 0; }
        
    </style>
</head>
<body>
<header>
    <h1?>Dr. P. N. Singh Degree college</h1>
    <h2>Our Non-Teaching Staff</h2>
</header>

<div class="staff-container">
    <?php while($row = $result->fetch_assoc()) { ?>
    <div class="staff-card">
        <img src="../static/uploads/<?php echo $row['image']; ?>">
        <h3><?php echo $row['name']; ?></h3>
        <p><b>Post:</b> <?php echo $row['post']; ?></p>
        <p><b>DOB:</b> <?php echo $row['dob']; ?></p>
        <p><b>DOJ:</b> <?php echo $row['doj']; ?></p>
        <p><b>DOR:</b> <?php echo $row['dor']; ?></p>
        <p><b>Contact:</b> <?php echo $row['contact']; ?></p>
    </div>
    <?php } ?>
</div>

<footer>
    <p>© 2025 Dr P N Singh Degree College</p>
</footer>
</body>
</html>

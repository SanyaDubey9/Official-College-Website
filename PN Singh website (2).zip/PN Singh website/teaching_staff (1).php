<?php
$conn = new mysqli("localhost", "u970167584_principal", "Sd11kk@09", "u970167584_college_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "SELECT * FROM teaching_staff";
$result = $conn->query($sql);

// Group staff by department
$staff = [];
while ($row = $result->fetch_assoc()) {
    $staff[$row['department']][] = $row;
}

// Custom department order
$priority = ["MUSIC", "HISTORY"];
$sorted_staff = [];

foreach ($priority as $dept) {
    if (isset($staff[$dept])) {
        $sorted_staff[$dept] = $staff[$dept];
        unset($staff[$dept]);
    }
}
ksort($staff);  // sort remaining alphabetically
$staff = $sorted_staff + $staff;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Teaching Staff - Dr. P. N. Singh Degree College</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Header styles */
    header {
      background: linear-gradient(90deg, #003366, #004080);
      color: white;
      padding: 20px 0;
    }
    header h1 {
      font-size: 28px;
      margin: 0;
    }
    .navbar {
      background-color: #004080;
    }
    .navbar a {
      color: white !important;
      font-weight: 500;
    }
    .navbar a:hover {
      text-decoration: underline;
    }

    /* Card Styles */
    .card-img-top {
      height: 500px;
      object-fit: cover;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }
    .card:hover {
      transform: scale(1.02);
    }

    /* Footer Styles */
    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 30px 10px;
      margin-top: 40px;
    }
    footer a {
      color: #ffcc00;
      text-decoration: none;
    }
    footer a:hover {
      text-decoration: underline;
    }

    h2, h4 {
      font-weight: bold;
    }
  </style>
</head>
<body class="bg-light">

<!-- Header -->
<header class="text-center">
  <div class="container">
    <h1>Dr. P. N. Singh Degree College, Chapra</h1>
    <p class="lead">Empowering Education with Excellence</p>
  </div>
</header>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="#">Teaching Staff</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Page Content -->
<div class="container my-5">
  <h2 class="text-center mb-4 text-primary">Our Teaching Staff</h2>

  <?php foreach ($staff as $dept => $profs): ?>
    <h4 class="mt-5 text-secondary border-bottom pb-2"><?php echo htmlspecialchars($dept ?? ''); ?> Department</h4>
    <div class="row">
      <?php foreach ($profs as $prof): ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="static/uploads/<?php echo htmlspecialchars($prof['photo'] ?? 'default.jpg'); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($prof['name'] ?? ''); ?>">
            <div class="card-body">
              <h5 class="card-title"><?php echo htmlspecialchars($prof['name'] ?? ''); ?></h5>
              <p class="card-text">
                <strong>Designation:</strong> <?php echo htmlspecialchars($prof['designation'] ?? ''); ?><br>
                <strong>DOB:</strong> <?php echo htmlspecialchars($prof['dob'] ?? ''); ?><br>
                <strong>Joining:</strong> <?php echo htmlspecialchars($prof['joining_date'] ?? ''); ?><br>
                <strong>Retirement:</strong> <?php echo htmlspecialchars($prof['retirement_date'] ?? ''); ?><br>
                <strong>Mode Of Appointment:</strong> <?php echo htmlspecialchars($prof['mode_of_appointment'] ?? ''); ?><br>
                <strong>Contact No:</strong> <?php echo htmlspecialchars($prof['mobileno'] ?? ''); ?>
              </p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</div>

<!-- Footer -->
<footer>
  <div class="container">
    <p>&copy; <?php echo date("Y"); ?> Dr. P. N. Singh Degree College, Chapra</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
